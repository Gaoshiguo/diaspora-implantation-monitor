app.views.NoPostsInfo = app.views.Base.extend({
  templateName: "no_posts_info"
});
