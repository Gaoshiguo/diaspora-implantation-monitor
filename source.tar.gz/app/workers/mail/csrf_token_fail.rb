# frozen_string_literal: true

module Workers
  module Mail
    class CsrfTokenFail < NotifierBase
    end
  end
end
