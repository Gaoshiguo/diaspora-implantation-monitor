# frozen_string_literal: true

module Workers
  module Mail
    class AlsoCommented < NotifierBase
    end
  end
end

