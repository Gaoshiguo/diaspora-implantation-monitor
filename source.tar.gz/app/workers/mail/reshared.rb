# frozen_string_literal: true

module Workers
  module Mail
    class Reshared < NotifierBase
    end
  end
end

