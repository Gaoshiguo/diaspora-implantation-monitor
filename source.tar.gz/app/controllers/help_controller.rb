# frozen_string_literal: true

class HelpController < ApplicationController
end
